main = conc(a) where a = "MC"
conc a = a + "911"
