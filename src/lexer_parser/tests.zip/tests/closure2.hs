main = filter(\ y -> y > x)([1,2,3])
where x = 1