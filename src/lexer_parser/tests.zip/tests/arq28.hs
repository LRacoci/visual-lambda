f x = {x:x}
main = {f(1):f(2)}