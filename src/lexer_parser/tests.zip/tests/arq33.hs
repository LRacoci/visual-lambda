main = a == b
  where a = "MC" + "911"
  where b = pi() * pi()
pi = 3.141592654
