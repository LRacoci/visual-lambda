main = if ( 0 < 1 ) then 2 else 1
