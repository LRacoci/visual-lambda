f n = n + 1

main n = f(n)