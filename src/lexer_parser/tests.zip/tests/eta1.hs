g y x = x + y
f = g(2)(1)
main = f()