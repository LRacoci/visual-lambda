-- Comentario

main = 0 + 1 -- outro

-- e mais um