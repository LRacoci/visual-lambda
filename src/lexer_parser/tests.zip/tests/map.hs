main = map(\ x -> map(\ y -> y + z)(x))([[1,2],[3,4]])
where z = 4