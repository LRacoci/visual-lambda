f a b = if if a < b then True else False then False else True
main = f(1)(2)