a = 3
main = f(a())