g y x = x + y
f x = g(x + 1)(1)
main = h()
h = f(1)