main = outro (1)(2)

outro a b = a + outra (b)

outra x = x / 3
