main = f([2])([1])
f a b = a+b
f a [1] = "oi"