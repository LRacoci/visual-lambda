main = f(1)
f x = map(\ y -> y+x)([1,2,3])