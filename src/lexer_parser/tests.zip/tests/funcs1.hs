main = 0

outro a b = a + b

outra b = b / 3
