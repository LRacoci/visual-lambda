main = filter(\ y -> y <= 2)(xs)
where xs = rest([4,2,3,1])