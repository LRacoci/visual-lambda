main = a
where b = (2.5, 5.7, "a", 3)
where a = b[2]
