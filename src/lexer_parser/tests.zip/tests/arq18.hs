main = f(2.5)
f a = if a < b then 1 else 0 where b = "MC911"
