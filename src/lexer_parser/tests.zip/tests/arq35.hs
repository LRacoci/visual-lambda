main = (a,b)
where c = 1
where d = 5
where a = (c,d)
where e = "M"
where f = "C"
where b = (e,f)
