main = f ()

f = if 1 == 0 then 1 else a()